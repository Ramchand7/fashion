<?php
include 'header.php';
?>
<div class="container mt-5" >
    <div class="row d-flex justify-content-center">
        <div class="col-md-6">
            <div class="card px-5 py-5" id="form1">
                <div class="form-data" v-if="!submitted">
                    <form method="POST">
                    <div class="forms-inputs mb-4"> <span>Email or username</span> <input autocomplete="off" type="email" v-model="email" name="email">
                        <div class="invalid-feedback">A valid email is required!</div>
                    </div>
     
                    <div class="mb-3"> <button type="submit" name="submit"  class="btn btn-dark w-100">Submit</button> </div>
                    </form>
                </div>
                <div class="success-data" v-else>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>


<?php
include 'footer.php';
?>
<?php
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $select="select * from signup where email='$email'";
    $selectqry=mysqli_query($con,$select);
    $countemail=mysqli_num_rows($selectqry);
    if($countemail>0){
        $to=$email;
        $subject="Change Password";
        $body="click here for activate account= http://localhost/fashion/forget-password-1.php?email=$email";
          $headers = "From:ramchand94786@gmail.com";
  if(mail($to,$subject,$body,$headers)){
     
      ?>
  <script>alert("we send email for varification")</script>
      <?php
  }else{
    ?>
    <script>alert("email not send try again")</script>
        <?php   
  }
}else{
        ?>
        <script>
alert('you have not account please register');
</script>
        <?php
    }
}
?>