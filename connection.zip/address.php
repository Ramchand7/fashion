<?php 
include 'header.php';
// get mobile and address from database

$select="select * from signup where email='$session_email'";
$selectqry=mysqli_query($con,$select);
$fetch=mysqli_fetch_assoc($selectqry);

?>
<div class="address_information">
<form method="POST">
<h1 class="head">ACCORDION</h1>
    <div class="accordion">
        <p class="title">Mobile No.</p>
        <span class="show">+</span>
    </div>
    <div class="info">
    <div class="item">
            <h3>Name</h3>
            <input type="text" name="buyer_name" value="<?php if(strlen($fetch['buyer_name']>1)){
                echo $fetch['buyer_name'];
            }; ?>" >
    </div>
    
    <div class="item">
            <h3  >Mobile No.  </h3>
            <input type="text" name="mobile" value="<?php if(strlen($fetch['mobile_no']>1)){
                echo $fetch['mobile_no'];
            }; ?>" >
        </div>
    </div>
    <div class="accordion">
        <p class="title">Address</p>
        <span class="show">+</span>
    </div>
<div class="info height">

    <div class="item">
        <h3>Address*</h3>
        <input type="text" name="address" value="<?php if(strlen($fetch['address']>1)){
                echo $fetch['address'];
            }; ?>" >
    </div>
    <div class="item">
        <h3>City*</h3>
        <input type="text" required name="city" value="<?php if(strlen($fetch['city']>1)){
                echo $fetch['city'];
            }; ?>" >
    </div>
    <div class="item">
        <h3>State *</h3>
        <input type="text" required name="state" value="<?php if(strlen($fetch['state']>1)){
                echo $fetch['state'];
            }; ?>" >
    </div>
    <div class="item">
        <h3>Pincode*</h3>
        <input type="text" required name="pincode" value="<?php if(strlen($fetch['pincode']>1)){
                echo $fetch['pincode'];
            }; ?>" >
    </div>
</div>
<div class="next-btn">
    <input type="button" value="Next" name="next">
</div>
 </form>
</div>

<?php
include 'footer.php';
if(isset($_POST['next'])){
$name=$_POST['buyer_name'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$pincode=$_POST['pincode'];

$update= "update signup buyer_name='$name', mobile='$mobile', address='$address', city='$city', state='$state', pincode='$pincode' where email='$session_email'";
$updateqry=mysqli_query($con,$update);
if($update){
    echo "updated";
}else{
    echo "not update";
}
}

?>
