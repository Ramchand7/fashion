<?php
  

include 'header.php';
include 'connection.php';

echo $previous_Page;
?>
<div class="login">
    
<div class="container" id="container">
        <div class="form-container sign-up-container">
            <form  method="POST" autocomplete="on">
                <h1>Create Account</h1>
           
                <input type="text" name="name" placeholder="Name" required />
                <input type="email" name="email" placeholder="Email" required />
                <input type="password" name="password" required placeholder="Minimum 5 Characters Password">
                <input type="password" name="confirmPassword" placeholder="Confirm Password" required/>

                <button type="submit" name="signup">Sign Up</button>

            </form>
        </div>
        <div class="form-container sign-in-container">
            <form action="#" method="POST" autocomplete="on">
                <h1>Sign in</h1>
                
                <input type="email" name="email" placeholder="Email" required />
                <input type="password" name="password" placeholder="Password" required />
                <a href="forget-password.php">Forgot your password?</a>
                <button type= "submit" name="signIn" >Sign In</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
              
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start journey with us</p>
                    <button class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
    </div>
</div>

    <?php
include 'footer.php';
    ?>

<?php 

if(isset($_POST['signIn'])){
$email=$_POST['email'];
$password=$_POST['password'];

$select="select * from signup where email='$email'";
$selectqry=mysqli_query($con,$select);
$emailcount=mysqli_num_rows($selectqry);
if($emailcount==1){
    $fetch=mysqli_fetch_assoc($selectqry);
    $get_Password=$fetch['password'];

    if(password_verify($password,$get_Password)){
      $_SESSION['email']=$email;
      
        header('location:index.php'); 
    }
    else{
        ?>
        <script>alert('password is not correct');</script>
                <?php  
    }
}else{
    ?>
    <script>alert('email is not registered');</script>
            <?php  
}

}

?>








    <?php
if(isset($_POST['signup'])) {
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$conPassword=$_POST['confirmPassword'];


$select="select * from signup where email='$email'";
$selectqry=mysqli_query($con,$select);
$emailcount=mysqli_num_rows($selectqry);

if($emailcount<1){
if(strlen($password)>5)
if($password===$conPassword){
    $password=password_hash($password,PASSWORD_DEFAULT);
    $insert="insert into signup(name, email, password ,activate) values('$name', '$email', '$password','not activate')";
    $insertqry=mysqli_query($con,$insert);   
    if($insertqry){
       
      $to=$email;
      $subject="email varification";
      $body="click here for activate account= http://localhost/fashion/activate.php?email=$email";
        $headers = "From:ramchand94786@gmail.com";
if(mail($to,$subject,$body,$headers)){
    $_SESSION['email']=$email;
    ?>
<script>alert("we send email for varification")</script>
    <?php
}else{
    ?>
<script>alert("email not send please try again")</script>
    <?php  
}
        }else{
        ?>
        <script>alert('data not insert');</script>
        <?php  
    }
}else{
    ?>
    <script>alert('confirm password is not correct');</script>
    <?php    
}else{
    ?>
    <script>alert('minimum 5 character  password valid');</script>
    <?php    
}
}
else{
?>
<script>alert('you have already account please login');</script>
<?php
}

}

?>