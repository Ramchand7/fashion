<?php

include 'connection.php';
$email='ramchand708786@gmail.com';
$insert="update signup set activate='activate' where email='$email'";
$insertqry=mysqli_query($con, $insert);
if($insertqry){
    ?>
<script>window.location='index.php';</script>
    <?php
}else{
    echo "not inserted";
}
?>