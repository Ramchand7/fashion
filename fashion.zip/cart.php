<?php
include 'header.php';
$getProductID = $_GET['id'];
$previous_Page= basename($_SERVER['HTTP_REFERER']); 
$email=@$_SESSION['email'];
if(isset($email)){
    $id=@$_GET['id'];
    $select="select * from upload_product where id='$id'";
    $selectqry=mysqli_query($con,$select);
    if($selectqry){
    $fetch=mysqli_fetch_assoc($selectqry);
    $id=$fetch['id'];
    $shop_name=$fetch['shop_name'];
    $brand=$fetch['brand'];
    $category=$fetch['category'];
    $title=$fetch['title'];
    $price=$fetch['price'];
    $image1=$fetch['image1'];
    $image2=$fetch['image2'];
    $image3=$fetch['image3'];
    $image4=$fetch['image4'];
    $discription=$fetch['discription'];
        $checkDuplicate="SELECT * FROM cart where email='$email' AND product_id=$getProductID";
        $exeDuplicate = mysqli_query($con, $checkDuplicate);
        $countRows = mysqli_num_rows($exeDuplicate);
      //  echo $countRows;
        if($countRows == 0) {
            $insert="insert into cart(product_id,shop_name, brand, category, title, price, image1, image2, image3, image4, discription, email, status) 
        values('$getProductID', '$shop_name','$brand','$category','$title', '$price','$image1', '$image2', '$image3', '$image4', '$discription','$email', 'unseen')"; 
        $insertqry=mysqli_query($con, $insert);
            if($insertqry){
                setcookie("message", "", time() -0.5);
                header('location:index.php');
            }else{
                ?>
            <script>
                alert("data not insert");
                </script>
                <?php
            }
        } else { 
            setcookie('message', 'product is already exist in cart',time()+15);
            header('location:http://localhost/fashion/'.$previous_Page);
                 }    
  }
    else{
        echo "product not found";
    }
}else{
    header('location:login.php');
    ?>
    <script>
        alert("Please Login First");
        </script>
        <?php
}

?>