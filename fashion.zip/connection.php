<?php
$user="root";
$password="";
$db="fashion";
$_server="localhost";
$con=mysqli_connect($_server,$user,$password,$db);

?>