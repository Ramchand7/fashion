
<div class="footer background">
    <div class="container">
        <div class="row1 row">
            <h2 class="widget-title">Links</h2>
            <ul>
              <li><a href= "#">Home</a></li>
              <li><a href= "#">Products</a></li>
              <li><a href= "#">Profile</a></li>
              <li><a href= "#">Login/signup</a></li>
              <li><a href= "#">cart</a></li>
                
            </ul>
        </div>
        <div class="row2 row ">
            <h2 class="widget-title" >Offers</h2>
            <ul>
            <li><a href= "#seller">Seller</a></li>
            <li><a href= "#feature-products">Feature Products</a></li>
              <li><a href= "#category">Top Products</a></li>
              <li><a href= "#Latest-Products">Latest Products</a></li>
              <li><a href= "#trending-deals">Trending deals</a></li>
             
               
            </ul>
        </div>
        <div class="row3 row">
            <h2 class="widget-title">Contacts Details</h2>            
               <div class="footer-contact">
                   <div class="icon"><i class="fas fa-phone-alt"></i></div>
                   <div class="detail">
                   <p class="content">Contact Us:</p>
                   <p class="content">1800 1800 180</p>
                   </div>
               </div>  
               <div class="footer-contact">
                   <div class="icon"><i class="far fa-envelope"></i></div>
                   <div class="detail">
                   <p class="content">Email Us:</p>
                   <p class="content">demo@gmail.com</p>
                   </div>
                   
               </div>           
        </div>
        <div class="row4 row">
            <h2 class="widget-title">Social Media</h2>
            <div class="footer-contact">
                   <div class="icon"><i class="fab fa-instagram"></i></div>
                   <p class="content"> Instagram</p>
               </div> 
               <div class="footer-contact">
                   <div class="icon"><i class="fab fa-facebook"></i></div>
                   <p class="content"> Facebook</p>
               </div> 
               <div class="footer-contact">
                   <div class="icon"><i class="fab fa-twitter"></i></div>
                   <p class="content"> Twitter</p>
               </div> 
        </div>
    </div>
</div>
<script>

/*------------- product-view------------*/


var ProductImg=document.getElementById('productImg');
var SmallImg1=document.getElementById('smallImg1');
var SmallImg2=document.getElementById('smallImg2');
var SmallImg3=document.getElementById('smallImg3');
var SmallImg4=document.getElementById('smallImg4');


		SmallImg1.onclick=function()
        { 
			ProductImg.src=SmallImg1.src;
		}
		SmallImg2.onclick=function()
		{
			ProductImg.src=SmallImg2.src;
		}
		SmallImg3.onclick=function()
		{
			ProductImg.src = SmallImg3.src;
		}
        SmallImg4.onclick=function()
		{
			ProductImg.src = SmallImg4.src;
		}
    </script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js" integrity="sha512-rCjfoab9CVKOH/w/T6GbBxnAH5Azhy4+q1EXW5XEURefHbIkRbQ++ZR+GBClo3/d3q583X/gO4FKmOFuhkKrdA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/javascript.js"></script>         
</body>
        </html>