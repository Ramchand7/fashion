<?php 

$discription=' Online Shopping India - Buy Clothes shoes and e-Gift Cards. Free Shipping & Cash on Delivery Available.';
$title='Profile';
$keywords=" Profile, Online Shoping, online shopping india, india shopping online, buy online, Clothes Shoping, Pants, Jacket, Shoes, Hoodie";

include 'header.php';
if(isset($_SESSION['email'])){
    // get username
$getusername="select * from signup where email='$session_email'";
$getusername_qry=mysqli_query($con,$getusername);
$getusername_qry_fetch=mysqli_fetch_assoc($getusername_qry);
// get products
$getProducts="select * from upload_product where email='ramchand708786@gmail.com' ORDER BY id DESC ";
$getProducts_qry=mysqli_query($con,$getProducts);
 $countProducts=mysqli_num_rows($getProducts_qry);
 //  get order list
$Order_list="select * from buy_product where buyer_email='$session_email' AND buy_success='buy'";
$Order_list_qry=mysqli_query($con, $Order_list);
$count_order_products=mysqli_num_rows($Order_list_qry);

?>

<div class="profile">

    <div class="container1">

        <div class="profile_img" style="background-color:#fff; border-radius:50%">
            <?php 
    if(!empty($getusername_qry_fetch['user_img'])){

    }else{
        ?>
            <img src="images/default_profile_img.jpg">
            <?php
    }
     ?>

        </div>
        <div class="username">
            <h2>
                <?php echo $getusername_qry_fetch['name']; ?>
            </h2>
            <p>
                <?php echo 'admin123456@gmail.com'; ?>
            </p>

        </div>

    </div>
    <div class="container">
        <div class="edit">
            <a href="#">
                <p>Edit</p>
            </a>
        </div>
        <div class="details">
            <div class="products">
                <h2>
                    <?php echo $countProducts; ?>
                </h2>
                <p>Products</p>
            </div>
            <div class="Sell">
                <h2>100</h2>
                <p>Selling Products</p>
            </div>
            <div class="Followers">
                <h2>100</h2>
                <p>Followers</p>
            </div>
        </div>
    </div>
</div>
<div class="profile1 ">
    <div class="container">
        <div class="mode">
            <div>
                <p class="mode-1" id="order_button" onclick="Your_Orders()">Your Orders</p>
            </div>
            <div>
                <p class="mode-2" id="product_button" onclick="Your_Products()">Your Products</p>
            </div>
        </div>
    </div>
</div>
<div class="feature-products" id="Your_products">

    <h4 class="profile_title">Your Products</h4>
    <?php
                if($countProducts>0){
           ?>
        <div class="profile2" id="toggle-products">
            <div class="container">
                <?php 
while($fetch=mysqli_fetch_assoc($getProducts_qry)){
    /// get sell details
    $product_id=$fetch['id'];
    $sellProduct="select * from buy_products where product_id='$product_id'";
    $sellProduct_qry=mysqli_query($con, $sellProduct);
    $sell_Products_fetch=mysqli_fetch_assoc($sellProduct_qry);

   
?>
                <div class="item">
                    <a href="product-view.php?id=<?php echo $fetch['id'];?>"><img
                        src="uploadImg/<?php echo $fetch['image1']; ?>"></a>
                    <a href="product-view.php?id=<?php echo $fetch['id'];?>">
                        <h3>
                            <?php echo $fetch['title'] ;?>
                        </h3>
                    </a>
                    <h4>Rs.
                        <?php echo $fetch['price'] ;?>
                    </h4>

                    <h4><i class="fas fa-eye"></i>
                        <?php echo $fetch['views']; ?>
                    </h4>
                    <h4>Buy </h4>
                    <div class="view-button">
                        <a href="product-view.php?id=<?php echo $fetch['id'];?>">
                            <p> view</p>
                        </a>
                        <a href="#">
                            <p> edit</p>
                        </a>
                    </div>
                </div>
                <?php
 }
}else{
    echo "<h3 style='text-align:center;margin:30px 0'>Product not exist</h3>";
}
?>
            </div>
        </div>
</div>
</div>
<!-------- order product--------->
<div class="profile3" id='Your_Orders'>
    <div class="cart-view">
        <div class="My-cart">
            <h4 class="profile_title">Your Orders</h4>
        </div>
        <div class="container2">
            <div class="products">
                <?php
       if($count_order_products<1){
           echo "<h3>Order List is Empty</h3>";
       }else{
       while($fetch_order_list=mysqli_fetch_assoc($Order_list_qry)){
        $order_product_id=$fetch_order_list['product_id'];
        $orderImg="select * from upload_product where id='$order_product_id'";
        $selectImg_qry=mysqli_query($con, $orderImg);
        $fetch_orderImg=mysqli_fetch_assoc($selectImg_qry);
        ?>
                    <div class="container" style="display:flex; justify-content:left;">
                        <div class="product-img">
                            <a href="product-view.php?id=<?php echo $fetch_order_list['product_id'];?>"><img
                                src="uploadImg/<?php echo $fetch_orderImg['image1']?>" alt=""></a>
                        </div>
                        <div class="products-details">
                            <h2 class="category">
                                <?php echo $fetch_order_list['category']; ?>
                            </h2>
                            <h2 class="title">
                                <?php echo $fetch_order_list['title']; ?>
                            </h2>
                            <h2 class="discription">
                                <?php  $result = substr($fetch_order_list['description'], 0, 100);
                                    echo $result."...";
            ?>
                            </h2>
                            <h2 class="price">&#x20B9
                                <?php echo $fetch_order_list['price'];?>
                            </h2>
                            <h2><i class="fas fa-eye"></i>
                                <?php echo $fetch_orderImg['views'];?>
                            </h2>
                            <div class="view-button">
                                <a href="product-view.php?id=<?php echo $fetch_order_list['product_id'];?>">
                                    <p> view</p>
                                </a>
                                <a href="cart-delete.php?id=<?php echo $fetch_order_list['product_id'];?>">
                                    <p> remove</p>
                                </a>
                            </div>
                        </div>

                    </div>
                    <hr>
                    <?php
        }
    }
        ?>
            </div>
        </div><br>
    </div>
</div>


<?php 
}else{
    echo '<h1 style="text-align:center; margin:20px 0">Not Exist Any Products</h1>';
}
include 'footer.php';

?>