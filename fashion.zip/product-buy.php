<?php
include 'header.php';
if(isset($_GET['$session_email'])){
    $id=$_GET['id'];
    if(isset($id)){

    }else{
      ?>
<script>
    alert("Product not fount try again");
    </script>
      <?php
    }
}else{
    header('location:login.php');
}


?>