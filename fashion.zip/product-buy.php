<?php
include 'header.php';
if(isset($session_email)){
    $product_id=$_GET['id'];
    if(isset($product_id)){
$select="select * from upload_product where id='$product_id'";
$selectqry=mysqli_query($con,$select);
$fetch=mysqli_fetch_assoc($selectqry);
$brand=$fetch['brand'];
$title=$fetch['title'];
$price=$fetch['price'];
$category=$fetch['category'];

$size=$_POST['size'];
$quantity=$_POST['quantity'];
$discription=$fetch['discription'];
$product_email=$fetch['email'];
$buyer_email=$session_email;

$date=strtotime("today");
$date =date("d-m-Y", $date);

/////// now data insert query

$insert="insert into buy_product(product_id,buyer_email, product_email, brand, category, title, price, size, quantity, description, date) 
Values ('$product_id', '$buyer_email','$product_email', '$brand', '$category','$title','$price', '$size', '$quantity', '$discription','$date')";
$insertqry=mysqli_query($con,$insert);
if($insertqry){
 header('location:address.php');
}else{
  ?>
  <script>
    alert('daat not insert');
    </script>
    <?php
}

    }else{
      ?>
<script>
    alert("Product not fount try again");
    </script>
      <?php
    }
}else{
    header('location:login.php');
}


?>