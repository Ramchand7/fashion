<?php
ob_start(); 
session_start();
@$previous_Page= basename($_SERVER['HTTP_REFERER']); 
$domain='location:http://localhost/fashion';
include 'connection.php';
 @$session_email= $_SESSION['email'];
$select="select * from signup where email='$session_email'";
$selectqry=mysqli_query($con,$select);

?>
<!DOCTYPE html>
<html lang="en">
<head>
   
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.min.css">
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="css/style.css">
<script>
    $("#notification").hide();
$(document).ready(function(){
  $("#search").keyup(function(){
      $this = $(this);
      var getProductName = $this.val();
      // alert(getProductName);
      $.ajax({
               //AJAX type is "Post".
               type: "POST",
               //Data will be sent to "ajax.php".
               url: "product.php",
               //Data, that will be sent to "ajax.php".
               data: {
                   product_name: getProductName
               },
               //If result found, this funtion will be called.
               success: function(html) {
                   //Assigning result to "display" div in "search.php" file.
               
                   $("#showProducts").text(html);
                   console.log(html);
               }
           });
  });
  /*----------cart-notification--------*/

});

setInterval(function(){
    
    $.ajax({url: "cart-notification.php",      
      success: function(result){

        console.log(result);
       $("#notification").html(result);
    if( result>0){
        $("#notification").show();

    }else{
        $("#notification").hide();
    }  
         }
         });
            }, 100);
</script>
</head>
<body>
        <nav>
            <div class="logo"><a href="index.php"><img src="images/nike.png" alt=""></a></div>
            <div class="search"><input type="search" placeholder="search" id="search" name="search"></div>
            <div class="mobile-nav" onClick="toggleMenu()"><i class="fas fa-bars" ></i></div>
            <ul id="menu">
            
                <li><a href="index.php">home</a></li>
                
                <li><a href="#">profile</a></li>
                <li><?php if($selectqry){
                    $fectch_data=mysqli_fetch_assoc($selectqry);
                    echo "<a href='#'>" .@$fectch_data['name']. "</a>";
                }
              ?></li>
             <li> <?php if(isset($_SESSION['email'])){
                   
                   echo "<a href='logout.php'>Logout</a>";
                    
              }else{
                  echo "<a href='login.php'>signup/login</a>";
              }
              
              ?></li>
               
                <li><a href="cart-view.php"><i class="fas fa-shopping-bag"></i></a></li>
             
            </ul>
               <span class="notification" id="notification" ><span>
        </nav>
      
    
