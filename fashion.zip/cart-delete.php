<?php
include 'header.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];
$delete="DELETE FROM `cart` WHERE email='$session_email' AND product_id='$id'";
$deleteqry=mysqli_query($con,$delete);
if($deleteqry){
    header('location:cart-view.php');
}
else{
    ?>
    <script>
        alert('some error please try again');
    </script>
        <?php
}
}else{
    ?>
<script>
    alert('try again');
</script>
    <?php
}
include 'footer.php';

?>