<?php
include 'header.php';
	$product_id=$_SESSION['id'];
	$select="select * from upload_product where id='$product_id'";
	
	$selectqry=mysqli_query($con,$select);
	$fetch=mysqli_fetch_assoc($selectqry);
// for get order_id
$select1="select * from buy_product where product_id='$product_id' AND buyer_email='$session_email'";
$selectqry1=mysqli_query($con,$select1);
$fetch1=mysqli_fetch_assoc($selectqry1);
 $order_id= $fetch1['order_id'];
?>
<div class="buy-product">
<div class="product-view">
    <div class="productImg">
     <div class="container-1">
        <div class="image-view"><img src="uploadImg/<?php echo $fetch['image1'];?>"  id="productImg" ></div>
    </div>
	<form method="post">
    <div class="details">
            <div class="brand"><?php echo $fetch['brand']; ?></div>
            <div class="title"><?php echo $fetch['title']; ?></div>
			<div class="size">
                <p>Size: <?php echo $fetch1['size'] ?></p>
            </div>
            <div class="size">
                <p>Quantity: <?php echo $fetch1['quantity'] ?></p>
            </div>
			<div class="size">
                <p>Price: <?php echo $fetch1['quantity_product_price']?></p>
            </div>
			<div class="size">
			<p>GST TAX :   <?php echo $fetch1['total_product_tax']; ?></p>
		
		   </div>
		   <div class="size">
			<p>Delivery Charge:  <?php echo $fetch1['delivery_charge'] ?></p>
			
		   </div>
			<div class="price">
			<div class="amount">
				<p>Total Amount: <?php echo $fetch1['total_price'] ?></p>
			</div>
			</div>
            <div class="check-out">
			<input value="Pay now" name="buy" type="submit">   
            </div>
        </div>
    </div>
</form>
	</div>
</div>
<?php
include 'footer.php';
if(isset($_POST['buy'])){
	$update="update buy_product set buy_success='buy', OrderDate='$date_time' where buyer_email='$session_email' And order_id='$order_id'";
	$update_qry=mysqli_query($con, $update);
	if($update_qry){
		header('location:product-buy-success.php');
	}else{
		?>
		<script>
			alert('try again');
		</script>
		<?php
	}
}

?>