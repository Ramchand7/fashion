<?php
 include 'header.php';
if(isset($_SESSION['email'])){
    $session_email= $_SESSION['email'];

echo $session_email;
    $select="SELECT * FROM cart where email = '$session_email' AND status='unseen'";
    $selectqry=mysqli_query($con,$select);
    $count=mysqli_num_rows($selectqry);
    
echo $count;
}else{
    echo "not login";
}
?>