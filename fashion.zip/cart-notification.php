<?php
include 'connection.php';
if(isset($_SESSION['email'])){

    $email=@$_SESSION['email'];
    $select="SELECT * FROM cart where email='ramchand708786@gmail.com' AND status='unseen'";
    $selectqry=mysqli_query($con,$select);
    $count=mysqli_num_rows($selectqry);
    
    if($count>9){
        echo  '9+'; 
    }else{
        echo $count;
    }
}else{
echo "";
}

?>