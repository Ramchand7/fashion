<?php
include 'header.php';
echo $session_email;
    $select="SELECT * FROM cart where email=$session_email AND status='unseen'";
    $selectqry=mysqli_query($con,$select);
    $count=mysqli_num_rows($selectqry);
    
    if($count>9){
        echo  '9+'; 
    }else{
        echo $count;
    }


?>