<?php
if(isset($_GET['id'])){
include 'header.php';

$product_id=@$_GET['id'];

//  for access id in other page
$_SESSION['id']=$product_id;
if(isset($_COOKIE['message'])){
    ?>
    <script>
    alert('<?php echo $_COOKIE['message']; ?>');
      </script>
    <?php
    }
    else{
      unset($_COOKIE['message']);
    }
if(isset($product_id)){
    $select="select * from upload_product where id='$product_id'";
    $selectqry=mysqli_query($con,$select);
    $fetch=mysqli_fetch_assoc($selectqry);
}else{
    echo "product not found";
}

?>
<div class="product-view">
    <div class="productImg">
     <div class="container-1">
        <div class="images"> 
            <div class="items "><img src="uploadImg/<?php echo $fetch['image1'];?>" id="smallImg1"></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image2'];?>"  id="smallImg2" ></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image3'];?>"  id="smallImg3"></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image4'];?>"  id="smallImg4"></div>
        </div>
        <div class="image-view"><img src="uploadImg/<?php echo $fetch['image1'];?>"  id="productImg" ></div>
    </div>
    <form method="POST">
    <div class="details">
            <div class="brand"><?php echo $fetch['brand']; ?></div>
            <div class="title"><?php echo $fetch['title']; ?></div>
            <div class="price">Rs. <?php echo $fetch['price']; ?></div>
            <div class="share">
                <p>Share</p>
                <ul>
                   <a href="https://web.whatsapp.com/send?text=http://localhost/fashion/product-view.php?id='<?php echo $product_id;?>' target='_blank'"><li ><i class="fab fa-whatsapp"></i></li></a>
                   <a href="http://www.facebook.com/sharer.php?u=http://localhost/fashion/product-view.php?id='<?php echo $product_id;?>' target='_blank'"><li><i class="fab fa-facebook-f"></i></li></a>
                   <a href="http://twitter.com/share?text='<?php echo $fetch['title'];?>'&url=http://localhost/fashion/product-view.php?id='<?php echo $product_id;?>' "><li><i class="fab fa-twitter"></i></li></a>
                   <a href=" http://pinterest.com/pin/create/button/?url=http://localhost/fashion/product-view.php?id='<?php echo $product_id;?>'"><li><i class="fab fa-pinterest"></i></li></a>
                </ul>
            </div>
            <div class="size">
                <p>Size</p>
                <select name="size">
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                </select> 
            </div>
            <div class="size">
                <p>Quantity</p>
              <input type="Number" name="quantity" value="1" min="1" class="quantity"> 
            </div>
            <div class="button">
          <input type="submit" name="submit" class="buy" value="buy it now">
         <input type="submit" class="cart" name="cart" value="cart">
            </div>
            <div class="product_detail">
                <h2>Product Details</h2>
                <p><?php echo $fetch['discription']; ?></p>
            </div>
        </div>
    </div>
</form>   
</div>
<div class="product-view1 ">
    <h2>you may also like</h2>
    <div class="container">
    <div class="owl-carousel owl-theme">
<?php 
$category=$fetch['category'];
$select3="select * from upload_product where category='$category'";
$selectqry3=mysqli_query($con,$select3);
while($res3=mysqli_fetch_assoc($selectqry3)){
 ?>
    <div class="item">
    <a href="product-view.php?id=<?php echo $res3['id'];?>"><img src="uploadImg/<?php echo $res3['image1']; ?>"></a>
      <h3><?php echo $res3['title']; ?></h3>
  <h4>Rs. <?php echo $res3['price']; ?></h4>
  <div class="view-button">
<a href="product-view.php?id=<?php echo $res3['id']?>"><p> view</p></a>
<a href="cart.php?id=<?php echo $res3['id'];?>"><p> cart</p></a>
</div>
    </div>
<?php 
}
?>
</div>
</div>
</div>
<?php
include 'footer.php';
if(isset($_POST['submit'])){
    /*$size=$_POST['size'];
    ?>
<script>
    alert('<?php echo $size ?>');
</script>
    <?php
*/

if(isset($session_email)){
  
    if(isset($_POST['submit'])){
    $select="select * from upload_product where id='$product_id'";
    $selectqry=mysqli_query($con,$select);
    $fetch=mysqli_fetch_assoc($selectqry);
    $brand=$fetch['brand'];
    $title=$fetch['title'];
    $price=$fetch['price'];
    $category=$fetch['category'];
    $size=$_POST['size'];
    $quantity=$_POST['quantity'];
    $discription=$fetch['discription'];
    $product_email=$fetch['email'];
    $buyer_email=$session_email;
    $date=strtotime("today");
    $date =date("d-m-Y", $date);

/////// now data insert query

    $insert="insert into buy_product(product_id,buyer_email, product_email, brand, category, title, price, size, quantity, description ) 
    Values ('$product_id', '$buyer_email','$product_email', '$brand', '$category','$title','$price', '$size', '$quantity', '$discription')";
    $insertqry=mysqli_query($con,$insert);
    if($insertqry){
    header('location:address.php');
    }else{
      ?>
      <script>
        alert('data not insert');
      </script>
        <?php
    }
        }
}else{
    header('location:login.php');
}
}
if(isset($_POST['cart'])){
    header("location:cart.php?id=product_id");
}
}else{
    echo "<h2>Product Not Found</h2>";
}
?>
