<?php
include 'header.php';
$id=@$_GET['id'];
if(isset($_COOKIE['message'])){
    ?>
    <script>
    alert('<?php echo $_COOKIE['message']; ?>');
      </script>
    <?php
    }
    else{
      unset($_COOKIE['message']);
    }
if(isset($id)){
    $select="select * from upload_product where id='$id'";
    $selectqry=mysqli_query($con,$select);
    $fetch=mysqli_fetch_assoc($selectqry);
}else{
    echo "product not found";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<div class="product-view">
    <div class="productImg">
     <div class="container-1">
        <div class="images"> 
            <div class="items "><img src="uploadImg/<?php echo $fetch['image1'];?>" id="smallImg1"></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image2'];?>"  id="smallImg2" ></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image3'];?>"  id="smallImg3"></div>
            <div class="items "><img src="uploadImg/<?php echo $fetch['image4'];?>"  id="smallImg4"></div>
        </div>
        <div class="image-view"><img src="uploadImg/<?php echo $fetch['image1'];?>"  id="productImg" ></div>
       
    </div>
    <form method="POST">
    <div class="details">
        
            <div class="brand"><?php echo $fetch['brand']; ?></div>
            <div class="title"><?php echo $fetch['title']; ?></div>
            <div class="price">Rs. <?php echo $fetch['price']; ?></div>
            <div class="share">
                <p>Share</p>
                <ul>
                    <li ><i class="fab fa-whatsapp"></i></li>
                    <li><i class="fab fa-facebook-f"></i></li>
                    <li><i class="fab fa-twitter"></i></li>
                    <li><i class="fab fa-instagram"></i></li>
                </ul>
            </div>
            <div class="size">
                <p>Size</p>
                <ul name="size">
                    <li value="S">S</li>
                    <li value="M">M</li>
                    <li value="L">L</li>
                    <li value="XL">XL</li>
                </ul>
               
            </div>
            <div class="button">
            <a href="product-buy.php?id=<?php echo $fetch['id'];?>"> <p name="buy">Buy it Now</p></a>
                <a href="cart.php?id=<?php echo $fetch['id'];?>"><p> cart</p></a>
            </div>
            <div class="product_detail">
                <h2>Product Details</h2>
                <p><?php echo $fetch['discription']; ?></p>
            </div>
        </div>
    </div>
</form>
    
</div>
<div class="product-view1 ">
    <h2>you may also like</h2>
    <div class="container">
    <div class="owl-carousel owl-theme">
<?php 
$category=$fetch['category'];
$select3="select * from upload_product where category='$category'";
$selectqry3=mysqli_query($con,$select3);
while($res3=mysqli_fetch_assoc($selectqry3)){
 ?>
    <div class="item">
    <a href="product-view.php?id=<?php echo $res3['id'];?>">  <img src="uploadImg/<?php echo $res3['image1']; ?>"></a>
      <h3><?php echo $res3['title']; ?></h3>
  <h4>Rs. <?php echo $res3['price']; ?></h4>
  <div class="view-button">
<a href="product-view.php?id=<?php echo $res3['id'];?>"><p> view</p></a>
<a href="cart.php?id=<?php echo $res3['id'];?>"><p> cart</p></a>
</div>
    </div>
<?php 
}
?>
</div>
</div>
</div>
<?php
include 'footer.php';
?>