<?php 
include 'header.php';
?>
<div class="address_information">
<h1 class="head">ACCORDION</h1>
    <div class="accordion">
        <p class="title">Mobile No.</p>
        <span class="show">+</span>
    </div>
    <div class="info">
    <div class="item">
            <h3>Name</h3>
            <input type="text" name="shop_name" placeholder=" 10 digit mobile no." >
    </div>
    
    <div class="item">
            <h3  >Mobile No.  </h3>
            <input type="text" name="shop_name" placeholder=" 10 digit mobile no." >
        </div>
    </div>
    <div class="accordion">
        <p class="title">Address</p>
        <span class="show">+</span>
    </div>
<div class="info height">

    <div class="item">
        <h3>Address</h3>
        <input type="text" name="address" placeholder="(Area and Street Name)" >
    </div>
    <div class="item">
        <h3>City*</h3>
        <input type="text" required name="city" placeholder=" " >
    </div>
    <div class="item">
        <h3>State *</h3>
        <input type="text" required name="brand" placeholder="" >
    </div>
    <div class="item">
        <h3>Pincode*</h3>
        <input type="text" required name="pincode" placeholder="" >
    </div>
</div>
<div>
    <input type="button" value="Next">
</div>
</div>

<?php
include 'footer.php';
?>