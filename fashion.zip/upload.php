<?php 
$discription=' Online Shopping India - Buy Clothes shoes and e-Gift Cards. Free Shipping & Cash on Delivery Available.';
$title='Upload Product | Became a seller';
$keywords="Online Shoping, online shopping india, india shopping online, buy online, Clothes Shoping, Pants, Jacket, Shoes, Hoodie";
include 'header.php';
if(!isset($_SESSION['email'])){
    ?>
    <script> alert("Please signup first")</script>
    <?php
    header('location:login.php'); 
}
?>
<div class="upload-container">
<div class="container">
    <div class="background-container">
    <h2>Publish  Product </h2>
    <form method="POST" enctype="multipart/form-data">
    <div class="grid">
        <div class="item">
            <h3>Shop name </h3>
            <input type="text" name="shop_name" placeholder=" Enter Your Shop/organisation" >
        </div>
        <div class="item">
            <h3>Brand name *</h3>
            <input type="text" required name="brand" placeholder=" Tommy, Gucci, Hrx, Nike" >
        </div>
        <div class="item">
            <h3>Category *</h3>
            <input type="text" required name="category" placeholder=" Pant, T-shirt, Shirt, Hoodie " >
        </div>
        <div class="item">
            <h3>Title *</h3>
            <input type="text" required name="title" placeholder="Short Discription" >
        </div>
        <div class="item">
            <h3>Price *</h3>
            <input type="text" required name="price" placeholder="Rs." >
        </div>
        <div class="item">
            <h3>size *</h3>
            <input type="text" required name="size" placeholder="S, M, L,XL." >
        </div>
        <div class="item">
            <h3> Product quantity *</h3>
            <input type="text" required name="quantity" placeholder="" >
        </div>
        <div class="item">
            <h3>image 1 *</h3>
            <input type="file"  required accept=".png, .jpg ,.jpeg, .webp" name="image_1" >
            </div>
            <div class="item">
                <h3>image 2 *</h3>
                <input type="file" required accept=".png, .jpg ,.jpeg, .webp"  name="image_2" >
            </div>
            <div class="item">
                <h3>image 3 *</h3>
                <input type="file" required accept=".png, .jpg ,.jpeg ,.webp"  name="image_3" >
            </div>
            <div class="item">
                <h3>image 4 *</h3>
                <input type="file" required accept=".png, .jpg ,.jpeg, .webp"  name="image_4" >
            </div>
    </div>
    <div class="item">
        <h3>Discription *</h3>
<textarea name="discription" required  rows="10"></textarea>
    </div>
    <div class="item submit">
        <input type="submit" name="submit" id="submit" >
    </div>
    </div>
</form>
</div>
</div>
<?php 
include 'footer.php';
?>
<?php
if(isset($_POST['submit'])){
    $shop_name=$_POST['shop_name'];
    $brand=$_POST['brand'];
    $category=$_POST['category'];
    $title=$_POST['title'];
    $price=$_POST['price'];
    $size=$_POST['size'];
    $quantity=$_POST['quantity'];
    $price=$_POST['price'];
    $image1=$_FILES['image_1'];
    $image2=$_FILES['image_2'];
    $image3=$_FILES['image_3'];
    $image4=$_FILES['image_4'];
    $discription=$_POST['discription'];


    $imagename1=$image1['name'];
    $imagetmp1=$image1['tmp_name'];
    $imagesize1=$image1['size'];
    $imagetype1=$image1['type'];
    $ext1 = pathinfo($imagetype1, PATHINFO_BASENAME);

    $imagename2=$image2['name'];
    $imagetmp2=$image2['tmp_name'];
    $imagesize2=$image2['size'];
    $imagetype2=$image2['type'];
    $ext2 = pathinfo($imagetype2, PATHINFO_BASENAME);

    $imagename3=$image3['name'];
    $imagetmp3=$image3['tmp_name'];
    $imagesize3=$image3['size'];
    $imagetype3=$image3['type'];
    $ext3 = pathinfo($imagetype3, PATHINFO_BASENAME);

    $imagename4=$image4['name'];
    $imagetmp4=$image4['tmp_name'];
    $imagetype4=$image4['type'];
    $imagesize4=$image4['size'];
    $ext4 = pathinfo($imagetype4, PATHINFO_BASENAME);

 
    $allow=['jpeg', 'png','jpg','webp'];
if(in_array($ext1,$allow) && in_array($ext2,$allow) && in_array($ext3,$allow) && in_array($ext4,$allow)){
if($imagesize1<= 1048576 && $imagesize2<= 1048576 && $imagesize3<= 1048576 && $imagesize4<= 1048576 ){
$dest1="uploadImg/". $imagename1;
$dest2="uploadImg/". $imagename2;
$dest3="uploadImg/". $imagename3;
$dest4="uploadImg/". $imagename4;
    
move_uploaded_file($imagetmp1,$dest1);
move_uploaded_file($imagetmp2,$dest2);
move_uploaded_file($imagetmp3,$dest3);
move_uploaded_file($imagetmp4,$dest4);

$insert="insert into upload_product (shop_name, brand, quantity, size, category, title, price, image1, image2, image3, image4, discription, email)
values('$shop_name', '$brand', '$quantity', '$size', '$category', '$title', '$price', '$imagename1', '$imagename2','$imagename3', '$imagename4', '$discription', '$session_email')";
$insertqry=mysqli_query($con,$insert);
if($insertqry){
    header('location:index.php');
}
else{
    ?>
    <script>alert("data is not inserted");
    </script>
    <?php   
}

}else{
    ?>
    <script>alert("image size allow max 1 mb ");
    </script>
    <?php   
}

}else{
    ?>
    <script>alert("only allow jpg, png, jpeg file");
    </script>
    <?php
}
}
?>