<?php
include './../header.php';
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");
	$product_id=$_SESSION['id'];
	$product_size=$_SESSION['size'];
	$product_quantity=$_SESSION['quantity'];
	$select="select * from upload_product where id='$product_id'";
	$selectqry=mysqli_query($con,$select);
	$fetch=mysqli_fetch_assoc($selectqry);
// for get order_id
$select1="select * from buy_product where product_id='$product_id' AND buyer_email='$session_email'";
$selectqry1=mysqli_query($con,$select1);
$fetch1=mysqli_fetch_assoc($selectqry1);
 $order_id= $fetch1['order_id'];
//get coustomer id
 $select2="select * from signup where email='$session_email'";
 $selectqry2=mysqli_query($con, $select2);
 $fetch2=mysqli_fetch_assoc($selectqry2);
 	 
?>
<div class="buy-product">
<div class="product-view">
    <div class="productImg">
     <div class="container-1">
        <div class="image-view"><img src="./../uploadImg/<?php echo $fetch['image1'];?>"  id="productImg" ></div>
    </div>
	<form method="post"  action='pgRedirect.php'>
    <div class="details">
            <div class="brand"><?php echo $fetch['brand']; ?></div>
            <div class="title"><?php echo $fetch['title']; ?></div>
			<input title="TXN_AMOUNT" tabindex="10"
						type="hidden" name="TXN_AMOUNT"
						value="<?php echo $fetch1['total_price'] ?>">
			<input type="hidden" id="ORDER_ID" tabindex="1" maxlength="20" size="20"
						name="ORDER_ID" readonly autocomplete="off"
						value="<?php echo  $fetch1['order_id'];?>">
			<input type="hidden" id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off"readonly value="<?php echo $fetch2['id'] ?>">
            <div class="size">
                <p>Size: <?php echo $fetch1['size'] ?></p>
            </div>
            <div class="size">
                <p>Quantity: <?php echo $fetch1['quantity'] ?></p>
            </div>
			<div class="size">
                <p>Price: <?php echo $fetch1['quantity_product_price']?></p>
            </div>
			<div class="size">
			<p>GST TAX :   <?php echo $fetch1['total_product_tax']; ?></p>
		
		   </div>
		   <div class="size">
			<p>Delivery Charge:  <?php echo $fetch1['delivery_charge'] ?></p>
			
		   </div>
			<div class="price">
			<div class="amount">
				<p>Total Amount: <?php echo $fetch1['total_price'] ?></p>
			</div>
			</div>
            <div class="check-out">
			<input value="Pay now" name="buy" type="submit" >   
            </div>
        </div>
    </div>
</form>
	</div>
</div>
<?php
include './../footer.php';


?>
<!--container.//-->
<!--container.//
</article>
<title>Merchant Check Out Page</title>
<meta name="GENERATOR" content="Evrsoft First Page">
</head>
<body>
	<h1>Product Information </h1>
	<pre>
	</pre>
	<form method="post" action="pgRedirect.php">
		<table border="1">
			<tbody>
				<tr>
					<th>S.No</th>
					<th>Label</th>
					<th>Value</th>
				</tr>
				<tr>
					<td>1</td>
					<td><label>ORDER_ID::*</label></td>
					<td><input id="ORDER_ID" tabindex="1" maxlength="20" size="20"
						name="ORDER_ID" autocomplete="off"
						value="<?php echo  $fetch1['order_id'];?>">
					</td>
				</tr>
				<tr>
					<td>2</td>
					<td><label>CUSTID ::*</label></td>
					<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
				</tr>
				<tr>
					<td>3</td>
					<td><label>INDUSTRY_TYPE_ID ::*</label></td>
					<td><input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
				</tr>
				<tr>
					<td>4</td>
					<td><label>Channel ::*</label></td>
					<td><input id="CHANNEL_ID" tabindex="4" maxlength="12"
						size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
					</td>
				</tr>
				<tr>
					<td>5</td>
					<td><label>txnAmount*</label></td>
					<td><input title="TXN_AMOUNT" tabindex="10"
						type="text" name="TXN_AMOUNT"
						value="100">
					</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><input value="CheckOut" type="submit"	onclick=""></td>
				</tr>
			</tbody>
		</table>
		* - Mandatory Fields
	</form>
-->