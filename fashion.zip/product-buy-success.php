<?php

$discription=' Online Shopping India - Buy Clothes shoes and e-Gift Cards. Free Shipping & Cash on Delivery Available.';
$title='Product Buy Successfull ';
$keywords="Online Shoping, online shopping india, india shopping online, buy online, Clothes Shoping, Pants, Jacket, Shoes, Hoodie";

include 'header.php';
?>
<div class="container4">
<div class="buy-success">
    <div class="image">
        <img src="images/success.gif" alt="success">
    </div>
    <div class="heading">
        <h2>Success</h2>
    </div>
    <a href="index.php"><input type="Submit" value="Home"></a>
</div>
</div>
<?php
include 'footer.php';
?>