<?php
include 'header.php';
?>
<div class="container4">
<div class="buy-success">
    <div class="image">
        <img src="images/success.gif" alt="success">
    </div>
    <div class="heading">
        <h2>Success</h2>
    </div>
</div>
</div>
<?php
include 'footer.php';
?>