<?php
include 'header.php';
$email=@$_SESSION['email'];

$select="select * from cart where email='$email' ORDER BY id DESC";
$selectqry=mysqli_query($con,$select);
 $count=mysqli_num_rows($selectqry);

if($count>0){

?>
<div class="cart-view">
    <div class="My-cart">
        <h2>My Bag</h2>
        </div>
  <div class="container2">
    <div class="products">
       <?php
       while($fetch=mysqli_fetch_assoc($selectqry)){

        ?>
     <div class="container">
        <div class="product-img">
        <a href="product-view.php?id=<?php echo $fetch['product_id'];?>"><img src="uploadImg/<?php echo $fetch['image1']?>" alt=""></a>
        </div>
        <div class="products-details">
        <a href="product-view.php?id=<?php echo $fetch['product_id'];?>"> <h2> <?php echo $fetch['title']; ?></h2></a>
            <p><?php echo $fetch['category']; ?></p>
            <p><?php  $result = substr($fetch['discription'], 0, 50);
             echo $result."...";
            ?></p>
            <h2> &#x20B9 <?php echo $fetch['price']; ?>  </h2>
            <div class="view-button">
                <a href="product-view.php?id=<?php echo $fetch['product_id'];?>"><p> view</p></a>
                <a href="cart-delete.php?id=<?php echo $fetch['product_id'];?>"><p> remove</p></a>
                </div>
        </div> 
        
     </div> 
     <hr>
     <?php
        }
        ?>
     
    </div>
    <div class="total-price products">
        <div class="cart-heading">
            <h2>Price Details</h2>
            </div>
            <div class="price-details">
              <div class="price-details-1">
                    <h2>Price (<?php echo $count.  ' item'; ?>)</h2>
                 <?php
                   $total_price=0;
                   $delivery_charge=50;
                   $select="select * from cart where email='$email' ORDER BY id DESC";
                   $selectqry=mysqli_query($con,$select);
                    while($fetch1=mysqli_fetch_assoc($selectqry)){
                      $total_price += $fetch1['price'];
                    }
                 ?>
                    <h2>  &#x20B9 <?php echo $total_price; ?></h2>
                </div>
                <div class="price-details-1">
                    <h2>Delivery Charges</h2>
                    <h2>  &#x20B9 <?php echo $delivery_charge; ?></h2>
              </div>
             </div>
                <div class="cart-heading ">
                    <h2>Total Amount</h2>
                    <h2>&#x20B9 <?php echo $total_price + $delivery_charge; ?></h2>
                </div>
            </div>
        </div>
    </div>
  </div>
 
</div>
<?php
}else{
    echo "<h1 style=text-align:center; margin:10% 0;> Not Available Any Product In Cart</h1>";
}
include 'footer.php';
?>