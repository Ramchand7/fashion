<?php

include 'header.php';
if(isset($_POST['product_name'])){
  
  $productName=$_POST['product_name'];

  $select="select * from upload_product where title LIKE '%$productName%' OR category LIKE  '%$productName%' ";
  $selectqry=mysqli_query($con, $select);
 echo mysqli_num_rows($selectqry);


?>
<div id="showProducts">
<div class="feature-products" id="feature-products" >
  <h2>Features Products</h2>
<div class="container">
<?php 
while($fetch=mysqli_fetch_assoc($selectqry)){
?>
<div class="item">
<a href="product-view.php?id=<?php echo $fetch['id'];?>"> <img src="uploadImg/<?php echo $fetch['image1']; ?>"></a>
<a href="product-view.php?id=<?php echo $fetch['id'];?>"> <h3><?php echo $fetch['title'] ;?></h3></a>
    <h4>Rs. <?php echo $fetch['price'] ;?></h4>
<div class="view-button">
<a href="product-view.php?id=<?php echo $fetch['id'];?>"><p> view</p></a>
<a href="cart.php?id=<?php echo $fetch['id'];?>"><p> cart</p></a>
</div>
  </div>
  <?php
}
?>
</div>
</div>
<div>
  <?php
}else{
  echo "data not found";
}

include 'footer.php';
?>