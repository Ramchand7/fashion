<?php
//include 'header.php';
if(isset($_POST['product_name'])){
  $productName=$_POST['product_name'];
   $productName;
  //echo "Product Name: ".$productName;
  //echo json_encode(array('title' => $title, 'price'=>$price));
}
?>
<div id="showProducts">
<?php 
   $productName;
?>
<div>
<?php 
//include 'footer.php';
?>