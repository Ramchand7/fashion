<?php
include'header.php';
?>
   
<div class="container mt-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-6">
            <div class="card px-5 py-5" id="form1">
                <div class="form-data">
                  <form method="POST">
                    <div class="forms-inputs mb-4"> <span>Password</span> <input autocomplete="off" type="password" v-model="password" name="password" placeholder="Minimum 5 Characters Password ">
                    </div>
                    <div class="forms-inputs mb-4"> <span>Confirm Password</span> <input autocomplete="off" type="password" v-model="password"  name="confirm-password">
                    </div>
     
                    <div class="mb-3"> <button type="submit" name="submit" class="btn btn-dark w-100">Update Password</button> </div>
                  </form>
                </div>
                <div class="success-data" v-else>
                </div>
            </div>
        </div>
    </div>
</div>
   
<?php
include 'footer.php';
?>
<?php 
if(isset($_POST['submit'])){
    $password=$_POST['password'];
    $conPassword=$_POST['confirm-password'];
    if($password===$conPassword){
$password=password_hash($password,PASSWORD_DEFAULT);
$update="update signup set password='$password'";
$updateqry=mysqli_query($con,$update);
if($update){
    header('location:login.php');
}
else{
?>
<script>alert('your password is not update')</script>
<?php
}
    }else{
        ?>
<script>
    alert('your confirm password is not correct');
</script>
        <?php
    }
 
}
?>