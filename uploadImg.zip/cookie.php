<?php

setcookie('email','ramchand708786@gmail.com',time()+(86400*365));
?>