<?php 
include 'header.php';
include 'connection.php';
$select="select * from upload_product limit 8";
$selectqry=mysqli_query($con,$select);

?>

  <div id="carouselExample1" class="carousel slide z-depth-1-half" data-ride="carousel" data-interval="2500">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>


  </ol>
  <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100" src="images/banner-3.jpg" alt="First slide" width=100% height=100%>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="images/banner-2.jpg" alt="Second slide" width=100% height=100%>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="images/banner-1.jpg" alt="Third slide" width=100% height=100%>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="images/banner-4.jpg" alt="Second slide" width=100% height=100%>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="images/banner-5.jpg" alt="Second slide" width=100% height=100%>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExample1" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExample1" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
<!---------------- became a seller ------------>
<div class="seller" id="seller">
  <div class="container">
    <div class="seller-background">
    <h2>want to became a seller</h2>
    </div>
    <a href="upload.php"> <input type="button" value="click here &#8594;"></a>
  </div>
</div>
    <!--------------------- feature images  ---------->
<div class="feature-products" id="feature-products" >
  <h2>Features Products</h2>
<div class="container">
<?php 
while($fetch=mysqli_fetch_assoc($selectqry)){
?>
<div class="item">
    <img src="uploadImg/<?php echo $fetch['image1']; ?>">
    <h3><?php echo $fetch['title'] ;?></h3>
    <h4>Rs. <?php echo $fetch['price'] ;?></h4>
<div class="view-button">
<h5> view</h5>
 <a herf="cart.php?id=<?php echo $fetch['id'];?>"><h5> cart</h5></a>
</div>
  </div>
  <?php
}
?>
</div>
</div>
<!-------------------------- 2nd section Top Products------------>
<div class="background" id="category">
<div class="container feature-products background" >
  <h2>Top Products</h2>
<div class="owl-carousel owl-theme">
<?php 
$select3="select * from upload_product limit 8 offset 24";
$selectqry3=mysqli_query($con,$select3);
while($res3=mysqli_fetch_assoc($selectqry3)){
 ?>
    <div class="item">
      <img src="uploadImg/<?php echo $res3['image1']; ?>">
      <h3><?php echo $res3['title']; ?></h3>
  <h4>Rs. <?php echo $res3['price']; ?></h4>
  <div class="view-button">
<h5> view</h5>
  <h5> cart</h5>
  </div>
    </div>
<?php 
}
?>
</div>
</div>
</div>
<!---------------------- 3rd section ------------------>
<div class="feature-products" id="Latest-Products">
  <h2>Latest Products</h2>
<div class="container">
<?php 
$select1="select * from upload_product limit 8 offset 8";
$selectqry1=mysqli_query($con,$select1);
while($res1=mysqli_fetch_assoc($selectqry1)){
 ?>
  <div class="item">
  <img src="uploadImg/<?php echo $res1['image1'];?>" >
  <h3><?php echo $res1['title'];?></h3>
  <h4>Rs.<?php echo $res1['price'];?></h4>
<div class="view-button">
<h5> view</h5>
<h5> cart</h5>
</div>
</div>
<?php
};
?>
</div>
</div>
<!----------------4th section--------------->
<div class="background-1" id="trending-deals">
<div class="container feature-products" >
  <h2>trending deals</h2>
<div class="owl-carousel owl-theme">
<?php 
$select4="select * from upload_product limit 10 offset 34";
$selectqry4=mysqli_query($con,$select4);
while($res4=mysqli_fetch_assoc($selectqry4)){
 ?>
    <div class="item">
      <img src="uploadImg/<?php echo $res4['image1']; ?>" alt="">
      <h3><?php echo $res4['title']; ?></h3>
  <h4>Rs. <?php echo $res4['price']; ?> </h4>
  <div class="view-button">
<h5> view</h5>
  <h5> cart</h5>
  </div>
    </div>
    <?php
}
?>
    
</div>
</div>
</div>
<!----------------4th section--------------->
<div class="feature-products" id="deals-of-the-day">
  <h2>Deals of the day</h2>
<div class="container">
<?php 
$select2="select * from upload_product limit 8 offset 16";
$selectqry2=mysqli_query($con,$select2);
while($res2=mysqli_fetch_assoc($selectqry2)){
 ?>
  <div class="item">
    <img src="uploadImg/<?php echo $res2['image1'];?>" >
    <h3><?php echo $res2['title']; ?></h3>
    <h4>Rs. <?php echo $res2['price']; ?></h4>
<div class="view-button">
<h5> view</h5>
  <h5> cart</h5>
</div>
  </div>
  <?php
}
?>
</div>
</div>
<!--------------------  5th section ------------------>
<div class="container feature-products brands " >
  <h2>Brands</h2>
<div class="owl-carousel owl-theme">
    <div class="item">
      <img src="images/adidas.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/gucci.png" alt="">
    </div>
    <div class="item">
      <img src="images/levis.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/manyavar.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/monte-carlo.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/nike.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/park-avenue.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/pepe-jeans.png" alt="">
      
   
    </div>
    <div class="item">
      <img src="images/peter-england.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/puma.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/raymond.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/reebok.png" alt="">
      
    </div>   
    <div class="item">
      <img src="images/tommy-hilfiger.png" alt="">
      
    </div>
    <div class="item">
      <img src="images/wrangler.png" alt="">
      
    </div> 
</div>
</div>
<?php
include 'footer.php';
?>