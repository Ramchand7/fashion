<?php
include 'header.php';
if(isset($_POST['search'])){
  $name=$_POST['search'];
  alert('hello');
}
?>

<?php 
include 'footer.php';
?>