<?php
include 'header.php';
?>
<div class="container4">
<div class="buy-success">
    <div class="image">
        <img src="images/success.gif" alt="success">
    </div>
    <div class="heading">
        <h2>Success</h2>
    </div>
    <a href="index.php"><input type="Submit" value="Home"></a>
</div>
</div>
<?php
include 'footer.php';
?>