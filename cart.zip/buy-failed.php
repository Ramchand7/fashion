<?php
include 'header.php';
$product_id=$_SESSION['id'];
echo $product_id;
?>

<div class="container4">
<div class="buy-success">
    <div class="image">
        <img src="images/failed.png" style="width:80%" alt="success">
    </div>
    
    <a href="http://localhost/fashion/product-view.php?id=<?php echo $product_id;?>"><input type="Submit" value="Home"></a>
</div>
</div>
<?php
include 'footer.php';
?>