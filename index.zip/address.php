<?php
include 'header.php';
/// check address
 $select="select * from signup where email='$session_email'";
 $selectqry=mysqli_query($con,$select);
$fetch=mysqli_fetch_assoc($selectqry);

if(($fetch['address']==0)){

?>
<div class="upload-container">
<div class="container">
    <div class="background-container">
    <h2>Publish  Product </h2>
    <form method="POST" enctype="multipart/form-data">
    <div class="grid">
    
        <div class="item">
            <h3>Address</h3>
            <input type="text" name="address" placeholder="Address( Area and Street)" >
        </div>
        <div class="item">
            <h3>City *</h3>
            <input type="text" required name="city" placeholder=" " >
        </div>
        <div class="item">
            <h3>State *</h3>
            <input type="text" required name="category" placeholder="" >
        </div>
        <div class="item">
            <h3>Pincode *</h3>
            <input type="text" required name="pincode" placeholder="" >
        </div>
        <div class="item">
            <h3>Mobile No. *</h3>
            <input type="text" required name="number"  placeholder="" >
        </div>
      
    </div>

   
    <div class="item submit">
        <input type="submit" name="submit" id="submit" >
    </div>
    </div>
</form>
</div>
</div>
<?php 
}else{
echo '0';
}
include 'footer.php';
?>